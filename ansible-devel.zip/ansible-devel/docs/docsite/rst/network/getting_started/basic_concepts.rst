**************
Basic Concepts
**************

These concepts are common to all uses of Ansible, including network automation. You need to understand them to use Ansible for network automation. This basic introduction provides the background you need to follow the examples in this guide.

.. contents::
   :local:

.. include:: ../../shared_snippets/basic_concepts.txt
